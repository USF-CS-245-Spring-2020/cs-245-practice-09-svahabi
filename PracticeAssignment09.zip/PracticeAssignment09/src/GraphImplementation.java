//NOTE: This class may reference lectures, canvas, peers, and other online sources
import java.util.ArrayList;
import java.util.List;
import java.util.*;

public class GraphImplementation implements Graph {

    private int vert;
    private int adjMatrix[][];

    public GraphImplementation(int v) {
        vert = v;
        adjMatrix = new int[vert][vert];
    }


    @Override
    public void addEdge(int v1, int v2) throws Exception {
        adjMatrix[v1][v2] = 1;
    }

    
    @Override
    public List<Integer> topologicalSort() {
        ArrayList<Integer> topSortList = new ArrayList<>();
        int[] incidents = new int[vert];
        for (int i=0; i<vert; i++) {
            for (int j=0; j<vert; j++) {
                if (adjMatrix[j][i] == 1) {
                    incidents[i]++;
                }
            }
        }
        while (topSortList.size() != vert) {
            for (int i=0; i < incidents.length; i++) {
                if (incidents[i] == 0) {
                    topSortList.add(i);
                    incidents[i] = -1;
                    for (int j=0; j < vert; j++) {
                        if (adjMatrix[i][j] != 0) {
                            incidents[j]--;
                        }
                    }
                }
            }
        }
        return topSortList;
    }


    @Override
    public List<Integer> neighbors(int vertex) throws Exception {
        List<Integer> nL = new ArrayList<>();
        for (int i = 0; i < vert;i++)
        {
            if (adjMatrix[vertex][i] > 0) {
                nL.add(i);
            }
        }
        return nL;
    }
}